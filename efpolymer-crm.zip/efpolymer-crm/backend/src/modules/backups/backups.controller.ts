import { Controller } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { BackupsService } from './Backups.service';

@ApiTags('Backups')
@Controller('Backups')
export class BackupsController {
  constructor(private readonly BackupsService: BackupsService) {}

  // TODO: Implement controller methods
}
