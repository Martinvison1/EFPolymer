import { Module } from '@nestjs/common';
import { BackupsService } from './Backups.service';
import { BackupsController } from './Backups.controller';

@Module({
  controllers: [BackupsController],
  providers: [BackupsService],
  exports: [BackupsService],
})
export class BackupsModule {}
